//
//  Etekcity_dict.swift
//  BLE scale
//
//  Created by Nicholas Gregorich on 11/25/23.
//

struct Scale {
    let name: String
    let service: String
    let characteristic: String
    let payloadLength: UInt8
    let stableByte: Int
    let stableValue: UInt8
    let mediaByte: Int
    let unitByte: Int
    let valueStartByte: Int
    let valueEndByte: Int
    let signByte: Int
}

let EtekcityNutritionScaleMedia: [UInt8: String] = [
    0x00: "",
    0x01: "water",
    0x02: "milk"
]

let EtekcityNutritionScaleUnits: [UInt8: String] = [
    0x00: "ounces",
    // Scale displays in whole lb and decimal ounces in 0x01,
    // the data is the same as in 0x00 "ounces"
    0x01: "ounces",
    0x02: "grams",
    0x03: "mL",
    0x04: "fl oz"
]

let EtekcityNutritionToKg: [UInt16: Float] =  [
    0x00_02: 1000.0, // none g
    0x01_03: 1000.0, // water mL
    0x02_03: 972.0,  // milk mL
    0x01_04: 33.85,  // water fl oz
    0x02_04: 32.90,  // milk fl oz
    0x00_00: 35.30,  // none oz
    0x00_01: 35.30   // none lb oz
]

// Swift byte     : 00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16
// Example payload:  a 52 20 70 00 b4 01 87 a1 00 00 44 02 00 02 00 01
var scaleStruct = Scale(name: "Etekcity Nutrition Scale",
                        service: "0xfff0",
                        characteristic: "0xfff1",
                        payloadLength: 17,
                        stableByte: 16,
                        stableValue: 0x01,
                        mediaByte: 15,
                        unitByte: 14,
                        valueStartByte: 12,
                        valueEndByte: 11,
                        signByte: 10)
