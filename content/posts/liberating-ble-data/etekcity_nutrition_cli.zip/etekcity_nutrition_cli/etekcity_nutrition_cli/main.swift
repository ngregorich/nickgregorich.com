//
//  main.swift
//  etekcity_nutrition_cli
//
//  Created by Nicholas Gregorich on 2/25/24.
//

import CoreBluetooth

let bleController = BLEController()

RunLoop.main.run()

class BLEController: NSObject, ObservableObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    
    let scaleServiceUUID = CBUUID.init(string: "fff0")
    let scaleCharacteristicUUID = CBUUID.init(string: "fff1")
    
    var myCentral: CBCentralManager!
    
    var scalePeripheral: CBPeripheral!
    
    override init() {
        print("Initializing Bluetooth Central")
        super.init()
        myCentral = CBCentralManager(delegate: self, queue: nil)
    }

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            print("Central is poweredOn")
            bleController.scanForScale()
        }
        else {
            print("Central is not poweredOn, exiting")
            exit(0)
        }
    }
    
    func scanForScale() {
        print("Scanning for: " + scaleStruct.name)
        myCentral.scanForPeripherals(withServices: nil, options: nil)
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        let unwrappedBLEName = peripheral.name ?? "NoBLEName"
        if unwrappedBLEName == scaleStruct.name {
            print("Discovered: " + unwrappedBLEName)
            scalePeripheral = peripheral
            central.stopScan()
            central.connect(scalePeripheral, options: nil)
        }
        else {}
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        print("Connected to identifier: \(peripheral.identifier)")
        peripheral.delegate = self
        peripheral.discoverServices(nil)
    }
    
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        if let error = error {
            print("Peripheral disconnected with error: \(error.localizedDescription)")
        } else {
            print("Peripheral disconnected")
        }
        scanForScale()
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let services = peripheral.services {
            for service in services {
                peripheral.discoverCharacteristics(nil, for: service)
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        
        var propertiesString = ""
        
        print("Discovered service: \(service.uuid)")
        if let characteristics = service.characteristics {
            for characteristic in characteristics {
                propertiesString = ""
                
                if characteristic.properties.contains(.read) {
                    propertiesString += "read "
                }
                if characteristic.properties.contains(.writeWithoutResponse) {
                    propertiesString += "write (no resp) "
                }
                
                if characteristic.properties.contains(.notify) {
                    peripheral.setNotifyValue(true, for: characteristic)
                    propertiesString += "notify"
                }
                
                print("Discovered characteristic: \(characteristic.uuid) " + propertiesString)
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        var scaleReading = Float(0)
        var scaleUnits = ""
        var scaleMedia = ""
        var stableString = ""
        
        if let value = characteristic.value {
            if value.count == scaleStruct.payloadLength {
                scaleReading = Float(UInt16(value[scaleStruct.valueStartByte]) << 8
                | UInt16(value[scaleStruct.valueEndByte]))
                
                if value[scaleStruct.signByte] != 0 {
                    scaleReading *= -1
                }
                
                scaleUnits = EtekcityNutritionScaleUnits[value[scaleStruct.unitByte]] ?? "Error: no units found"

                if ["grams", "mL"].contains(scaleUnits) {
                    scaleReading /= 10
                }
                else if ["fl oz", "ounces"].contains(scaleUnits) {
                    scaleReading /= 100
                }
                scaleMedia = EtekcityNutritionScaleMedia[value[scaleStruct.mediaByte]] ?? "Error: no media found"

                if value[scaleStruct.stableByte] == scaleStruct.stableValue {
                    stableString = "stable"
                }
                else {
                    stableString = "unstbl"
                }

                print("\(Int64(Date().timeIntervalSince1970 * 1000)) \(stableString): \(scaleReading) \(scaleUnits) \(scaleMedia)")
            }
        }
    }
}
